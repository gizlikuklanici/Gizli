ADANA TR CRAFT v7 — BDcraft SES / EL / MENÜ DÜZELTMESİ
=====================================================

Bu paket, önceki v6 arşivinin mevcut dosyalarını koruyarak hazırlanmıştır.
`index.html` güncellenmiştir; v6 paketindeki diğer dosyalar kaldırılmamıştır.

Bu sürümde yapılanlar:
- BDcraft Sound Pack MC121 içindeki 293 ses dosyası, özgün klasör yolları
  korunarak `assets/minecraft/sounds/` altına eklendi.
- Orijinal ses paketi değiştirilmeden `source_packs/BDcraft Sound Pack MC121.zip`
  içinde de tutuldu.
- Ahşap kazıma, taş kazıma, yaprak/ot, adım, eşya yerleştirme, oyuncu hasarı,
  ok, kalkan, sandık ve yaratık hasarı/ölümü gibi olaylar ayrı ses kaynaklarına
  bağlandı. Mevcut olaylarda dosyadaki varyantlardan rastgele seçim yapılır.
- Boş elde ilk şahıs kolu; eşya tutulduğunda ise basit 3D geometrili eşya modeli
  gösterilir. Kılıç, kazma, balta, kürek, yay, kova, yiyecek, blok ve kalkan için
  ayrı şekiller vardır. Kırma/saldırı/yeme sırasında sallanma animasyonu eklenmiştir.
- Envanter ekranı açılınca hotbar tamamen gizlenir; kapatılınca yeniden görünür.
- Ana menü, gönderilen Bedrock örneklerine yakın düz gri/pikselli düğmeler ve
  sağda karakter önizlemesiyle yeniden biçimlendirildi.
- Ayarlar düğmesinin yanına Acil Çıkış eklendi; boş sekme açmayı dener, açılmazsa
  mevcut sekmeyi boş sayfaya götürür.
- Basit Kırmızı Yatak bloğu eklendi: meşe tahta + kırmızı yün tarifiyle üretilebilir.
  Yatağa sağ tıklamak doğma noktasını yatağa ayarlar; geceyse zamanı sabaha alır.
- Mevcut kırma çatlağı/partikül sistemi ve önceki Nether/End/Stronghold deneysel
  kodu korunmuştur.

Önemli sınırlar:
Bu, Minecraft'ın tam bir 1.20 kopyası değildir. Nether ve End arazi üretimi bu
projedeki mevcut deneysel sistemdir; stronghold da basitleştirilmiş bir yapıdır.
Yatağın animasyonu, çift bloklu Minecraft yatağı modeli ve bütün tarif kitabı
içeriği bu pakette tam vanilla seviyesine getirilmiş değildir. First-person eldeki
eşya modeli 3D küplerle temsil edilir; tüm gerçek oyun modellerinin/dokularının
piksel piksel kopyası değildir.

Çalıştırma:
1. ZIP'i Windows'ta yeni bir klasöre çıkar.
2. `index.html` dosyasını aç. Bazı tarayıcılar `file://` adresinden büyük dosyalar
   veya WebGL kaynakları için kısıtlama uygulayabilir; sorun olursa yerel bir
   HTTP sunucusu üzerinden aç.
3. Ses oynatımı tarayıcının ilk kullanıcı etkileşiminden sonra etkinleşebilir.
Türkçe açıklamalar UTF-8 olarak kaydedilmiştir.
