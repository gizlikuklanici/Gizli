ADANA TR CRAFT v6 - KONTROL, SES VE TARIF KITABI DUZELTMELERI

Kurulum:
1) ZIP'i tamamen bir klasore cikartin.
2) index.html dosyasini Chrome gibi guncel bir tarayicida acin.
3) assets/sounds klasorunu index.html ile ayni klasorde tutun. Sesler goreli yollardan yuklenir.

Bu surumde:
- Her tus basiminda adim sesi calinmasi kaldirildi. Adim sesi yalnizca hareket simülasyonundan gelir ve zeminin ses ailesine gore degisir.
- Blok kirma sesleri malzeme ismine gore secilir; ahsap ve tas ayni dosyayi kullanmaz. Her ses birden fazla numarali varyanttan rastgele secilir.
- Kalkan, zırh kuşanma, sandık, üretim, hasar ve eşya alma sesleri için yerel dosyalar kullanilir; internetten ses cekme gereksinimi azaltildi.
- Tarif Kitabi panelinin gorunurluk ve yan panel yerlesimi duzeltildi; tarifler listelenir, secilince malzeme durumu ve dizme eylemi gosterilir.
- Envanter acikken hotbar ve mobil oyun kontrolleri dokunma alanini kaplamaz.
- Sohbet dugmesi ekranin ust soluna tasindi.
- Yaratıcı modda mobil ZIPLA dugmesine cift dokunarak ucus acilip kapatilabilir; basili tutma yukselmeye yarar.

Not: Bu proje bagimsiz bir HTML voxel prototipidir; resmi Minecraft istemcisi degildir. Ses dosyalari kullanicinin sagladigi 1.17 ses arsivinden secilerek projeye dahil edilmistir. Gercek cihazda manuel oyun testi bu calisma ortaminda yapilamadi.
